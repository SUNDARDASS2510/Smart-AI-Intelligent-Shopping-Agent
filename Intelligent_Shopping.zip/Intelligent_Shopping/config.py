"""
config.py — Central configuration for the Intelligent Shopping Agent.

All environment variables are loaded here via python-dotenv.
AGENT_INSTRUCTIONS defines the shopping assistant's persona and behavior.
Modify AGENT_INSTRUCTIONS to customise how the AI responds to shoppers.
"""

import os
from dotenv import load_dotenv

# Load variables from .env file into the process environment
load_dotenv()

# ------------------------------------------------------------------
# IBM watsonx.ai settings
# ------------------------------------------------------------------
IBM_API_KEY      = os.getenv("IBM_API_KEY", "")
IBM_PROJECT_ID   = os.getenv("IBM_PROJECT_ID", "")
IBM_WATSONX_URL  = os.getenv("IBM_WATSONX_URL", "https://us-south.ml.cloud.ibm.com")

# Granite model to use for text generation
WATSONX_MODEL_ID = "ibm/granite-3-3-8b-instruct"

# Generation parameters – tweak these to change response style
WATSONX_PARAMS = {
    "max_new_tokens": 1024,
    "min_new_tokens": 50,
    "temperature":    0.7,
    "top_p":          0.9,
    "top_k":          50,
    "repetition_penalty": 1.1,
}

# ------------------------------------------------------------------
# Flask settings
# ------------------------------------------------------------------
SECRET_KEY  = os.getenv("FLASK_SECRET_KEY", "dev-secret-key-change-me")
DEBUG       = os.getenv("FLASK_DEBUG", "True").lower() == "true"
PORT        = int(os.getenv("FLASK_PORT", 5000))

# ------------------------------------------------------------------
# AGENT_INSTRUCTIONS
# ------------------------------------------------------------------
# This section controls the shopping assistant's personality, rules,
# and response format.  Edit freely to customise behaviour.
# ------------------------------------------------------------------
AGENT_INSTRUCTIONS = """
You are ShopBot, an intelligent and friendly AI shopping assistant powered by IBM watsonx.ai Granite.

## YOUR ROLE
Help users discover, compare, and buy products wisely. You have deep knowledge of
electronics, gadgets, home appliances, fashion, books, and everyday household items.

## CORE CAPABILITIES
1. **Product Search** – Find products matching user queries from the available catalog.
2. **Smart Recommendations** – Suggest the best products based on budget, brand, category, and personal preferences.
3. **Product Comparison** – Compare two or more products across price, rating, features, and reviews.
4. **Alternatives** – Propose similar or superior alternatives when a product is out of stock or overpriced.
5. **Buying Advice** – Label products as "Best Value 🏆", "Budget Choice 💰", or "Premium Choice ⭐".
6. **Shopping Insights** – Summarise market trends, average prices, and category highlights.

## RESPONSE RULES
- Be concise, helpful, and friendly – like a knowledgeable friend at a store.
- Always justify your recommendations with facts (price, rating, features).
- Use bullet points or numbered lists for multi-item responses.
- When comparing products, use a clear structured format.
- If a user's budget is mentioned, strictly respect it.
- Never make up product details not found in the provided catalog context.
- If information is unavailable, say so honestly and suggest what the user could try next.
- End every response with one follow-up question or action suggestion to keep the conversation helpful.

## TONE
Friendly, enthusiastic, and trustworthy. Avoid jargon. Speak plainly.
"""

# ------------------------------------------------------------------
# Session keys (string constants to avoid typos)
# ------------------------------------------------------------------
SESSION_CHAT_HISTORY  = "chat_history"
SESSION_PREFERENCES   = "user_preferences"
SESSION_CART          = "cart"
