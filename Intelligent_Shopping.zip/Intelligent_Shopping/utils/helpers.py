"""
utils/helpers.py — Shared utility functions for the shopping agent.

Functions:
  sanitize_input(text)            → strip and truncate user input
  format_chat_message(role, text) → create a chat turn dict
  truncate_text(text, max_len)    → safe text truncation with ellipsis
  format_price(value)             → "$1,299.99" style formatting
  stars(rating)                   → "★★★★☆" visual star string
"""

import re
import html


# Maximum character length accepted from user input
MAX_INPUT_LENGTH = 1000


def sanitize_input(text: str) -> str:
    """
    Cleans user input:
      - Strips leading/trailing whitespace
      - Escapes HTML entities to prevent injection
      - Truncates to MAX_INPUT_LENGTH characters
      - Collapses internal whitespace runs to a single space
    """
    if not isinstance(text, str):
        text = str(text) if text is not None else ""

    text = text.strip()
    text = html.escape(text)                    # prevent XSS
    text = re.sub(r"\s+", " ", text)           # collapse whitespace
    text = text[:MAX_INPUT_LENGTH]              # length limit
    return text


def format_chat_message(role: str, content: str) -> dict:
    """
    Returns a standardised chat message dict.

    Parameters
    ----------
    role    : "user" or "assistant"
    content : The message text.
    """
    allowed_roles = {"user", "assistant"}
    if role not in allowed_roles:
        role = "user"
    return {"role": role, "content": content}


def truncate_text(text: str, max_len: int = 120) -> str:
    """
    Truncates text to max_len characters, appending '…' if cut.
    Tries to break on the last word boundary.
    """
    if not text or len(text) <= max_len:
        return text
    truncated = text[:max_len].rsplit(" ", 1)[0]
    return truncated + "…"


def format_price(value: float | int) -> str:
    """Returns a USD price string, e.g. format_price(1299.9) → '$1,299.90'"""
    try:
        return f"${float(value):,.2f}"
    except (TypeError, ValueError):
        return "N/A"


def stars(rating: float) -> str:
    """
    Converts a numeric rating (0–5) into a Unicode star string.
    E.g. stars(4.3) → '★★★★☆'
    """
    try:
        full  = int(round(float(rating)))
        full  = max(0, min(5, full))
        empty = 5 - full
        return "★" * full + "☆" * empty
    except (TypeError, ValueError):
        return "☆☆☆☆☆"
