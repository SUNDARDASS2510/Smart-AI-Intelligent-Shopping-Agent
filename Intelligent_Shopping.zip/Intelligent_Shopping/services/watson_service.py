"""
services/watson_service.py — IBM watsonx.ai Granite integration.

This module handles all communication with IBM watsonx.ai.
It builds prompts from chat history + product context, calls the
Granite model, and returns the plain-text assistant response.
"""

import re
from ibm_watsonx_ai import APIClient, Credentials
from ibm_watsonx_ai.foundation_models import ModelInference
from config import (
    IBM_API_KEY,
    IBM_PROJECT_ID,
    IBM_WATSONX_URL,
    WATSONX_MODEL_ID,
    WATSONX_PARAMS,
    AGENT_INSTRUCTIONS,
)

# ── Module-level singleton to avoid re-authenticating on every request ──
_model: ModelInference | None = None


def _get_model() -> ModelInference:
    """
    Returns a cached ModelInference instance.
    Authenticates with IBM Cloud on the first call.
    """
    global _model
    if _model is None:
        if not IBM_API_KEY or IBM_API_KEY == "your_ibm_api_key_here":
            raise ValueError(
                "IBM_API_KEY is not set. Please update your .env file."
            )
        if not IBM_PROJECT_ID or IBM_PROJECT_ID == "your_watsonx_project_id_here":
            raise ValueError(
                "IBM_PROJECT_ID is not set. Please update your .env file."
            )

        credentials = Credentials(
            url=IBM_WATSONX_URL,
            api_key=IBM_API_KEY,
        )
        client = APIClient(credentials=credentials, project_id=IBM_PROJECT_ID)
        _model = ModelInference(
            model_id=WATSONX_MODEL_ID,
            api_client=client,
            params=WATSONX_PARAMS,
        )
    return _model


def _build_prompt(
    user_message: str,
    chat_history: list[dict],
    product_context: list[dict],
    preferences: dict,
) -> str:
    """
    Constructs a full prompt string from:
      - AGENT_INSTRUCTIONS (system persona)
      - User shopping preferences
      - Relevant product catalog context
      - Recent conversation history
      - The current user message
    """
    parts = [AGENT_INSTRUCTIONS.strip()]

    # ── Preferences block ────────────────────────────────────────────
    if any(preferences.values()):
        pref_lines = ["## USER PREFERENCES"]
        if preferences.get("budget"):
            pref_lines.append(f"- Budget: ${preferences['budget']}")
        if preferences.get("category"):
            pref_lines.append(f"- Category: {preferences['category']}")
        if preferences.get("brand"):
            pref_lines.append(f"- Preferred brand: {preferences['brand']}")
        if preferences.get("keywords"):
            pref_lines.append(f"- Keywords: {preferences['keywords']}")
        parts.append("\n".join(pref_lines))

    # ── Product context block ────────────────────────────────────────
    if product_context:
        ctx_lines = ["## AVAILABLE PRODUCTS (from catalog)"]
        for i, p in enumerate(product_context[:8], 1):
            ctx_lines.append(
                f"{i}. {p.get('name', 'Unknown')} | "
                f"${p.get('price', 0):.2f} | "
                f"Rating: {p.get('rating', 'N/A')}/5 | "
                f"Category: {p.get('category', 'N/A')} | "
                f"Brand: {p.get('brand', 'N/A')} | "
                f"Features: {', '.join(p.get('features', [])[:3])}"
            )
        parts.append("\n".join(ctx_lines))

    # ── Conversation history block ───────────────────────────────────
    if chat_history:
        history_lines = ["## CONVERSATION HISTORY"]
        for msg in chat_history[-6:]:   # last 3 exchanges
            role    = msg.get("role", "user").capitalize()
            content = msg.get("content", "")
            history_lines.append(f"{role}: {content}")
        parts.append("\n".join(history_lines))

    # ── Current user turn ────────────────────────────────────────────
    parts.append(f"## CURRENT USER MESSAGE\nUser: {user_message}")
    parts.append("ShopBot:")   # model will complete from here

    return "\n\n".join(parts)


def get_ai_response(
    user_message: str,
    chat_history: list[dict] | None = None,
    product_context: list[dict] | None = None,
    preferences: dict | None = None,
) -> str:
    """
    Public interface: call the Granite model and return the assistant reply.

    Parameters
    ----------
    user_message    : The latest message from the user.
    chat_history    : Prior conversation turns (list of {role, content} dicts).
    product_context : Relevant products to inject into the prompt.
    preferences     : User's saved shopping preferences.

    Returns
    -------
    str — The model's plain-text response, cleaned up.
    """
    chat_history    = chat_history    or []
    product_context = product_context or []
    preferences     = preferences     or {}

    try:
        model  = _get_model()
        prompt = _build_prompt(user_message, chat_history, product_context, preferences)

        result = model.generate_text(prompt=prompt)

        # Trim any accidental prompt echo or extra whitespace
        response = result.strip() if isinstance(result, str) else str(result).strip()
        response = re.sub(r"^ShopBot:\s*", "", response)   # remove leading echo
        return response if response else "I'm sorry, I couldn't generate a response. Please try again."

    except ValueError as ve:
        # Configuration errors (missing API key, etc.)
        return f"⚠️ Configuration Error: {ve}"

    except Exception as exc:
        # Network / API errors – surface a user-friendly message
        error_msg = str(exc)
        if "authentication" in error_msg.lower() or "401" in error_msg:
            return "⚠️ Authentication failed. Please check your IBM_API_KEY in the .env file."
        if "not found" in error_msg.lower() or "404" in error_msg:
            return f"⚠️ Model not found: {WATSONX_MODEL_ID}. Check your IBM_PROJECT_ID."
        return f"⚠️ I encountered an issue connecting to the AI service: {error_msg[:120]}"
