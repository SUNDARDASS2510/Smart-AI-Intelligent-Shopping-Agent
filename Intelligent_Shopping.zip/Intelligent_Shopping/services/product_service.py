"""
services/product_service.py — In-memory product catalog and search logic.

No database is used. Products are defined as Python dictionaries.
Add or remove products from PRODUCT_CATALOG to expand the catalog.

Functions exported:
  search_products(query, limit)    → keyword/fuzzy search
  get_all_products(category_filter) → full catalog, optionally filtered
  get_products_by_ids(ids)         → fetch by numeric ID list
  get_product_insights()           → aggregated stats for charts
"""

import re
from typing import Optional

# ── ─────────────────────────────────────────────────────────────────
# PRODUCT CATALOG
# Each product is a plain Python dict.  Feel free to add more products!
# ─────────────────────────────────────────────────────────────────────
PRODUCT_CATALOG: list[dict] = [
    # ── Electronics ──────────────────────────────────────────────────
    {
        "id": 1, "name": "Sony WH-1000XM5 Headphones",
        "category": "Electronics", "brand": "Sony",
        "price": 349.99, "rating": 4.8, "reviews": 4520,
        "features": ["Noise Cancelling", "30hr Battery", "Bluetooth 5.2", "Foldable"],
        "description": "Industry-leading noise cancellation with crystal-clear sound.",
        "badge": "Best Value 🏆", "in_stock": True,
    },
    {
        "id": 2, "name": "Apple AirPods Pro (2nd Gen)",
        "category": "Electronics", "brand": "Apple",
        "price": 249.00, "rating": 4.7, "reviews": 8900,
        "features": ["Active Noise Cancellation", "Transparency Mode", "H2 Chip", "MagSafe"],
        "description": "Redesigned with more powerful noise cancellation and adaptive audio.",
        "badge": "Premium Choice ⭐", "in_stock": True,
    },
    {
        "id": 3, "name": "Anker Soundcore Q45 Headphones",
        "category": "Electronics", "brand": "Anker",
        "price": 59.99, "rating": 4.4, "reviews": 2100,
        "features": ["ANC", "50hr Battery", "Bluetooth 5.3", "Foldable"],
        "description": "Excellent budget headphones with impressive noise cancellation.",
        "badge": "Budget Choice 💰", "in_stock": True,
    },
    {
        "id": 4, "name": "Samsung Galaxy Tab S9",
        "category": "Electronics", "brand": "Samsung",
        "price": 699.99, "rating": 4.6, "reviews": 3200,
        "features": ["Snapdragon 8 Gen 2", "11-inch AMOLED", "S Pen", "Wi-Fi 6E"],
        "description": "Flagship Android tablet with stunning display and S Pen included.",
        "badge": "Premium Choice ⭐", "in_stock": True,
    },
    {
        "id": 5, "name": "Amazon Fire HD 10 Tablet",
        "category": "Electronics", "brand": "Amazon",
        "price": 149.99, "rating": 4.2, "reviews": 15000,
        "features": ["10.1-inch Full HD", "Octa-core", "12hr Battery", "Alexa Built-in"],
        "description": "Affordable tablet for streaming, reading, and everyday tasks.",
        "badge": "Budget Choice 💰", "in_stock": True,
    },
    {
        "id": 6, "name": "Dell XPS 15 Laptop",
        "category": "Laptops", "brand": "Dell",
        "price": 1799.99, "rating": 4.7, "reviews": 2800,
        "features": ["Intel Core i7-13700H", "16GB RAM", "512GB SSD", "OLED Display"],
        "description": "Powerful laptop with a stunning OLED display for creatives.",
        "badge": "Premium Choice ⭐", "in_stock": True,
    },
    {
        "id": 7, "name": "Acer Aspire 5 Laptop",
        "category": "Laptops", "brand": "Acer",
        "price": 599.99, "rating": 4.3, "reviews": 5600,
        "features": ["AMD Ryzen 5", "8GB RAM", "256GB SSD", "15.6-inch FHD"],
        "description": "Best-in-class budget laptop for students and professionals.",
        "badge": "Best Value 🏆", "in_stock": True,
    },
    {
        "id": 8, "name": "MacBook Air M3",
        "category": "Laptops", "brand": "Apple",
        "price": 1299.99, "rating": 4.9, "reviews": 6700,
        "features": ["Apple M3 Chip", "8GB RAM", "256GB SSD", "15hr Battery", "MagSafe"],
        "description": "The thinnest, lightest MacBook Air ever with breakthrough M3 performance.",
        "badge": "Premium Choice ⭐", "in_stock": True,
    },
    {
        "id": 9, "name": "Logitech MX Master 3S Mouse",
        "category": "Accessories", "brand": "Logitech",
        "price": 99.99, "rating": 4.8, "reviews": 7800,
        "features": ["8000 DPI", "Quiet Clicks", "USB-C Charging", "Multi-device"],
        "description": "Advanced wireless mouse for maximum productivity.",
        "badge": "Best Value 🏆", "in_stock": True,
    },
    {
        "id": 10, "name": "Keychron K2 Mechanical Keyboard",
        "category": "Accessories", "brand": "Keychron",
        "price": 89.99, "rating": 4.6, "reviews": 4300,
        "features": ["Hot-swappable", "RGB Backlight", "Bluetooth 5.1", "Compact 75%"],
        "description": "Popular compact mechanical keyboard for Mac and Windows.",
        "badge": "Best Value 🏆", "in_stock": True,
    },
    # ── Home Appliances ───────────────────────────────────────────────
    {
        "id": 11, "name": "Dyson V15 Detect Vacuum",
        "category": "Home Appliances", "brand": "Dyson",
        "price": 699.99, "rating": 4.7, "reviews": 3100,
        "features": ["Laser Dust Detection", "HEPA Filtration", "60-min Battery", "LCD Display"],
        "description": "Dyson's most powerful cordless vacuum with laser dust detection.",
        "badge": "Premium Choice ⭐", "in_stock": True,
    },
    {
        "id": 12, "name": "Shark IZ462H Vacuum",
        "category": "Home Appliances", "brand": "Shark",
        "price": 249.99, "rating": 4.4, "reviews": 4900,
        "features": ["Anti-Allergen", "LED Headlights", "Flexible wand", "60-min Battery"],
        "description": "Powerful cordless vacuum at a fraction of Dyson's price.",
        "badge": "Best Value 🏆", "in_stock": True,
    },
    {
        "id": 13, "name": "Instant Pot Duo 7-in-1",
        "category": "Kitchen", "brand": "Instant Pot",
        "price": 79.99, "rating": 4.7, "reviews": 22000,
        "features": ["7 Functions", "6-Quart", "Pressure Cooker", "Dishwasher Safe"],
        "description": "The world's best-selling multi-cooker – saves time and money.",
        "badge": "Best Value 🏆", "in_stock": True,
    },
    {
        "id": 14, "name": "Nespresso Vertuo Plus",
        "category": "Kitchen", "brand": "Nespresso",
        "price": 159.99, "rating": 4.5, "reviews": 8700,
        "features": ["Centrifusion Tech", "5 Cup Sizes", "One-touch brewing", "Fast Heat-up"],
        "description": "Brew barista-quality coffee at the touch of a button.",
        "badge": "Premium Choice ⭐", "in_stock": True,
    },
    {
        "id": 15, "name": "Black+Decker CM1160B Coffee Maker",
        "category": "Kitchen", "brand": "Black+Decker",
        "price": 29.99, "rating": 4.1, "reviews": 9400,
        "features": ["12-Cup Carafe", "Programmable", "Keep Warm Plate", "Pause n Pour"],
        "description": "Reliable everyday coffee maker at an unbeatable price.",
        "badge": "Budget Choice 💰", "in_stock": True,
    },
    # ── Fitness ───────────────────────────────────────────────────────
    {
        "id": 16, "name": "Apple Watch Series 9",
        "category": "Fitness", "brand": "Apple",
        "price": 399.00, "rating": 4.8, "reviews": 11000,
        "features": ["S9 Chip", "Blood Oxygen", "ECG", "Crash Detection", "Always-On Display"],
        "description": "The most capable Apple Watch yet with a new double-tap gesture.",
        "badge": "Premium Choice ⭐", "in_stock": True,
    },
    {
        "id": 17, "name": "Fitbit Charge 6",
        "category": "Fitness", "brand": "Fitbit",
        "price": 159.95, "rating": 4.3, "reviews": 4600,
        "features": ["Heart Rate", "GPS", "SpO2", "7-day Battery", "Google Maps"],
        "description": "Advanced fitness tracker with built-in GPS and Google apps.",
        "badge": "Best Value 🏆", "in_stock": True,
    },
    {
        "id": 18, "name": "Xiaomi Mi Band 8",
        "category": "Fitness", "brand": "Xiaomi",
        "price": 39.99, "rating": 4.2, "reviews": 6800,
        "features": ["SpO2 Monitor", "16-day Battery", "150+ Sports Modes", "AMOLED"],
        "description": "Feature-packed fitness band at an amazing budget price.",
        "badge": "Budget Choice 💰", "in_stock": True,
    },
    # ── Books ─────────────────────────────────────────────────────────
    {
        "id": 19, "name": "Atomic Habits – James Clear",
        "category": "Books", "brand": "Penguin",
        "price": 16.99, "rating": 4.9, "reviews": 45000,
        "features": ["Self-help", "Productivity", "Bestseller", "Audiobook available"],
        "description": "Tiny changes, remarkable results. The #1 habit-building book.",
        "badge": "Best Value 🏆", "in_stock": True,
    },
    {
        "id": 20, "name": "The Pragmatic Programmer",
        "category": "Books", "brand": "Addison-Wesley",
        "price": 49.99, "rating": 4.8, "reviews": 12000,
        "features": ["Software Engineering", "Career", "20th Anniversary Edition"],
        "description": "A must-read for every software developer.",
        "badge": "Premium Choice ⭐", "in_stock": True,
    },
]


# ── ─────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────

def _score_product(product: dict, keywords: list[str]) -> int:
    """
    Returns a relevance score for a product based on keyword matches.
    Higher = more relevant.
    """
    score = 0
    searchable = " ".join([
        product.get("name", ""),
        product.get("category", ""),
        product.get("brand", ""),
        product.get("description", ""),
        " ".join(product.get("features", [])),
    ]).lower()

    for kw in keywords:
        if kw in searchable:
            score += 2
        elif any(kw in word for word in searchable.split()):
            score += 1
    return score


def _extract_budget(query: str) -> Optional[float]:
    """Parse a budget figure from a query string, e.g. 'under $500' → 500.0"""
    match = re.search(r"\$?\s*(\d[\d,]*(?:\.\d+)?)", query)
    if match:
        return float(match.group(1).replace(",", ""))
    return None


# ── ─────────────────────────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────────────────────────────

def search_products(query: str, limit: int = 8) -> list[dict]:
    """
    Keyword search across product name, category, brand, description, features.
    Returns products sorted by relevance score.
    """
    if not query:
        return []

    # Tokenise query into individual keywords (≥2 chars)
    keywords = [w.lower() for w in re.split(r"\W+", query) if len(w) >= 2]
    budget   = _extract_budget(query)

    results = []
    for product in PRODUCT_CATALOG:
        score = _score_product(product, keywords)
        if score > 0:
            # Apply budget filter if detected
            if budget and product["price"] > budget * 1.05:  # 5% tolerance
                continue
            results.append((score, product))

    results.sort(key=lambda x: (-x[0], -x[1]["rating"]))
    return [p for _, p in results[:limit]]


def get_all_products(category_filter: str = "") -> list[dict]:
    """
    Returns the full product catalog, optionally filtered by category.
    """
    if not category_filter:
        return PRODUCT_CATALOG
    cf = category_filter.lower()
    return [p for p in PRODUCT_CATALOG if p["category"].lower() == cf]


def get_products_by_ids(ids: list[int]) -> list[dict]:
    """Returns products whose IDs appear in the given list."""
    id_set = set(ids)
    return [p for p in PRODUCT_CATALOG if p["id"] in id_set]


def get_product_insights() -> dict:
    """
    Computes aggregated shopping insights for the dashboard charts.
    Returns counts, averages, and distributions over the catalog.
    """
    from collections import Counter

    categories  = [p["category"] for p in PRODUCT_CATALOG]
    brands      = [p["brand"]    for p in PRODUCT_CATALOG]
    prices      = [p["price"]    for p in PRODUCT_CATALOG]
    ratings     = [p["rating"]   for p in PRODUCT_CATALOG]
    badges      = [p.get("badge", "").split()[0] for p in PRODUCT_CATALOG if p.get("badge")]

    category_counts = dict(Counter(categories))
    brand_counts    = dict(Counter(brands))
    badge_counts    = dict(Counter(badges))

    price_ranges = {"Under $50": 0, "$50–$200": 0, "$200–$500": 0, "$500–$1000": 0, "Over $1000": 0}
    for price in prices:
        if price < 50:
            price_ranges["Under $50"] += 1
        elif price < 200:
            price_ranges["$50–$200"] += 1
        elif price < 500:
            price_ranges["$200–$500"] += 1
        elif price < 1000:
            price_ranges["$500–$1000"] += 1
        else:
            price_ranges["Over $1000"] += 1

    return {
        "total_products":     len(PRODUCT_CATALOG),
        "categories":         category_counts,
        "top_brands":         dict(sorted(brand_counts.items(), key=lambda x: -x[1])[:8]),
        "price_distribution": price_ranges,
        "badge_counts":       badge_counts,
        "avg_price":          round(sum(prices) / len(prices), 2),
        "avg_rating":         round(sum(ratings) / len(ratings), 2),
        "highest_rated":      max(PRODUCT_CATALOG, key=lambda p: p["rating"])["name"],
        "lowest_price":       min(PRODUCT_CATALOG, key=lambda p: p["price"])["name"],
    }
