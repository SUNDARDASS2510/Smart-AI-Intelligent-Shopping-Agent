"""
services/recommendation_service.py — AI recommendation and comparison logic.

Functions exported:
  recommend_products(preferences, query, limit) → preference-filtered list
  compare_products(query)                        → best-match pair/group
  get_buying_advice(products)                    → labelled advice dict
"""

import re
from services.product_service import PRODUCT_CATALOG, search_products


def recommend_products(
    preferences: dict,
    query: str = "",
    limit: int = 8,
) -> list[dict]:
    """
    Returns products that best match the user's stated preferences.

    Preference keys (all optional):
      budget   – maximum price (number)
      category – category name string
      brand    – preferred brand string
      keywords – free-text keywords string
    """
    candidates = list(PRODUCT_CATALOG)   # work on a copy

    # ── Filter by budget ─────────────────────────────────────────────
    budget = preferences.get("budget")
    if budget:
        try:
            budget_val = float(budget)
            candidates = [p for p in candidates if p["price"] <= budget_val]
        except (ValueError, TypeError):
            pass   # ignore malformed budget

    # ── Filter by category ───────────────────────────────────────────
    category = (preferences.get("category") or "").strip().lower()
    if category:
        candidates = [p for p in candidates if p["category"].lower() == category]

    # ── Filter by brand (soft match) ─────────────────────────────────
    brand = (preferences.get("brand") or "").strip().lower()
    if brand:
        candidates = [p for p in candidates if brand in p["brand"].lower()]

    # ── Keyword boost from preferences + live query ───────────────────
    keyword_str = " ".join([
        preferences.get("keywords") or "",
        query,
    ]).strip()

    if keyword_str:
        kws = [w.lower() for w in re.split(r"\W+", keyword_str) if len(w) >= 2]
        # score + sort
        scored = []
        for p in candidates:
            score = 0
            text  = f"{p['name']} {p['category']} {p['brand']} {p['description']} {' '.join(p['features'])}".lower()
            for kw in kws:
                if kw in text:
                    score += 1
            scored.append((score, p))
        scored.sort(key=lambda x: (-x[0], -x[1]["rating"]))
        candidates = [p for _, p in scored]
    else:
        # Default sort: highest rated first
        candidates.sort(key=lambda p: -p["rating"])

    # If budget filtered down to nothing, fall back to cheapest products
    if not candidates and budget:
        fallback = sorted(PRODUCT_CATALOG, key=lambda p: p["price"])
        return fallback[:limit]

    return candidates[:limit]


def compare_products(query: str) -> list[dict]:
    """
    Extracts product names from a comparison query and returns the best
    matching products.  Falls back to a general keyword search.

    Example query: "compare Sony WH-1000XM5 vs Apple AirPods Pro"
    """
    # Try to split on common comparison separators
    for sep in [" vs ", " versus ", " or ", " and ", " compared to "]:
        if sep in query.lower():
            parts = re.split(sep, query, flags=re.IGNORECASE, maxsplit=1)
            left  = _find_best_match(parts[0].strip())
            right = _find_best_match(parts[1].strip())

            results = []
            if left:
                results.append(left)
            if right and (not left or right["id"] != left["id"]):
                results.append(right)
            if results:
                return results

    # Generic keyword search when no separator detected
    found = search_products(query, limit=4)
    return found[:4]


def _find_best_match(text: str) -> dict | None:
    """Returns the single best-matching product for a text fragment."""
    results = search_products(text, limit=1)
    return results[0] if results else None


def get_buying_advice(products: list[dict]) -> dict:
    """
    Analyses a list of products and labels them as:
      - Best Value 🏆  (highest rating-to-price ratio)
      - Budget Choice 💰 (lowest price among the set)
      - Premium Choice ⭐ (highest rated)

    Returns a dict mapping product IDs to their advice label.
    """
    if not products:
        return {}

    # --- Best Value: highest (rating / price) ratio
    best_value = max(
        products,
        key=lambda p: p["rating"] / max(p["price"], 0.01),
    )

    # --- Budget: cheapest
    budget_pick = min(products, key=lambda p: p["price"])

    # --- Premium: highest rating
    premium_pick = max(products, key=lambda p: p["rating"])

    advice: dict[int, str] = {}
    advice[best_value["id"]]   = "Best Value 🏆"
    advice[budget_pick["id"]]  = "Budget Choice 💰"
    advice[premium_pick["id"]] = "Premium Choice ⭐"

    return advice
