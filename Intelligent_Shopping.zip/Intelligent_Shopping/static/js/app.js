/**
 * app.js — Intelligent Shopping Agent Frontend
 *
 * Responsibilities:
 *  - Chat send/receive with streaming-style rendering
 *  - Product card rendering (grid)
 *  - Insights modal with Chart.js visualisations
 *  - Preferences form submission
 *  - Quick-search chip / example-chip clicks
 *  - Auto-resizing textarea
 *  - Graceful error handling
 */

"use strict";

/* ── DOM references ─────────────────────────────────────────── */
const chatContainer    = document.getElementById("chat-container");
const messagesEl       = document.getElementById("messages");
const chatInput        = document.getElementById("chat-input");
const sendBtn          = document.getElementById("send-btn");
const typingIndicator  = document.getElementById("typing-indicator");
const productsSection  = document.getElementById("products-section");
const productsGrid     = document.getElementById("products-grid");
const productsTitle    = document.getElementById("products-title");
const chatWelcome      = document.getElementById("chat-welcome");
const prefForm         = document.getElementById("preferences-form");
const prefStatus       = document.getElementById("pref-status");
const insightsModal    = document.getElementById("insights-modal");
const insightsBody     = document.getElementById("insights-body");
const btnInsights      = document.getElementById("btn-insights");
const btnClearChat     = document.getElementById("btn-clear-chat");
const btnCloseProducts = document.getElementById("btn-close-products");
const closeInsights    = document.getElementById("close-insights");

/* ── State ──────────────────────────────────────────────────── */
let isBotTyping = false;   // prevent concurrent requests
let insightsLoaded = false;
let categoryChartInst = null;
let priceChartInst    = null;

/* ── Category → Emoji Map ───────────────────────────────────── */
const CATEGORY_EMOJI = {
  electronics:       "🔌",
  laptops:           "💻",
  accessories:       "🖱️",
  "home appliances": "🏠",
  kitchen:           "🍳",
  fitness:           "🏃",
  books:             "📚",
};

/* =============================================================
   CHAT
   ============================================================= */

/**
 * Sends the current input text to /api/chat and renders the response.
 */
async function sendMessage() {
  const text = chatInput.value.trim();
  if (!text || isBotTyping) return;

  // Clear welcome screen on first message
  if (chatWelcome) chatWelcome.style.display = "none";

  appendMessage("user", text);
  chatInput.value = "";
  resizeTextarea();
  setTyping(true);

  try {
    const res  = await fetch("/api/chat", {
      method:  "POST",
      headers: { "Content-Type": "application/json" },
      body:    JSON.stringify({ message: text }),
    });

    const data = await res.json();

    if (!res.ok) {
      appendMessage("bot", `⚠️ ${data.error || "Something went wrong."}`);
      return;
    }

    appendMessage("bot", data.response || "I'm not sure how to answer that.");

    // Show product cards if the API returned any
    if (data.products && data.products.length > 0) {
      renderProducts(data.products, `🔍 Results for: "${text}"`);
    }

  } catch (err) {
    appendMessage("bot", "⚠️ Network error. Please check your connection and try again.");
    console.error("[ShopBot] Chat error:", err);
  } finally {
    setTyping(false);
  }
}

/**
 * Appends a message bubble to the chat window.
 * @param {"user"|"bot"} role
 * @param {string} text
 */
function appendMessage(role, text) {
  const wrap = document.createElement("div");
  wrap.className = `message message-${role === "user" ? "user" : "bot"}`;

  const avatar = document.createElement("div");
  avatar.className = "message-avatar";
  avatar.textContent = role === "user" ? "👤" : "🤖";

  const bubble = document.createElement("div");
  bubble.className = "message-bubble";
  // Render newlines and preserve basic markdown-like bold (**text**)
  bubble.innerHTML = formatMessageText(text);

  const time = document.createElement("span");
  time.className = "message-time";
  time.textContent = getTime();

  wrap.appendChild(avatar);
  const inner = document.createElement("div");
  inner.style.display = "flex";
  inner.style.flexDirection = "column";
  inner.style.gap = "4px";
  inner.appendChild(bubble);
  inner.appendChild(time);
  wrap.appendChild(inner);

  messagesEl.appendChild(wrap);
  scrollToBottom();
}

/**
 * Converts plain text to safe HTML with basic formatting.
 * Supports **bold**, *italic*, and converts newlines to <br>.
 */
function formatMessageText(text) {
  // Escape HTML first
  const escaped = text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");

  return escaped
    .replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>")   // **bold**
    .replace(/\*(.+?)\*/g, "<em>$1</em>")                 // *italic*
    .replace(/\n/g, "<br />");                             // newlines
}

/** Shows / hides the typing indicator. */
function setTyping(active) {
  isBotTyping = active;
  typingIndicator.hidden = !active;
  sendBtn.disabled = active;
  if (active) scrollToBottom();
}

/** Scrolls the chat window to the latest message. */
function scrollToBottom() {
  chatContainer.scrollTop = chatContainer.scrollHeight;
}

/** Returns current HH:MM time string. */
function getTime() {
  return new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

/* =============================================================
   PRODUCT CARDS
   ============================================================= */

/**
 * Renders an array of product objects as cards in the products grid.
 * @param {Array}  products  - Array of product dicts from the API
 * @param {string} title     - Section heading text
 */
function renderProducts(products, title = "🛍 Products") {
  if (!products || products.length === 0) {
    productsSection.hidden = true;
    return;
  }

  productsTitle.textContent = title;
  productsGrid.innerHTML = "";

  products.forEach(p => {
    const card = buildProductCard(p);
    productsGrid.appendChild(card);
  });

  productsSection.hidden = false;
  // Scroll to products
  productsSection.scrollIntoView({ behavior: "smooth", block: "nearest" });
}

/**
 * Builds a single product card DOM element.
 * @param {Object} p - Product dict
 * @returns {HTMLElement}
 */
function buildProductCard(p) {
  const card = document.createElement("div");
  card.className = "product-card";

  // Badge
  if (p.badge) {
    const badge = document.createElement("span");
    badge.className = "product-badge " + getBadgeClass(p.badge);
    badge.textContent = p.badge;
    card.appendChild(badge);
  }

  // Emoji icon based on category
  const emoji = document.createElement("div");
  emoji.className = "product-emoji";
  emoji.textContent = CATEGORY_EMOJI[(p.category || "").toLowerCase()] || "🛒";
  card.appendChild(emoji);

  // Name
  const name = document.createElement("div");
  name.className = "product-name";
  name.textContent = p.name || "Unknown Product";
  card.appendChild(name);

  // Brand · Category
  const meta = document.createElement("div");
  meta.className = "product-brand-cat";
  meta.textContent = `${p.brand || "—"}  ·  ${p.category || "—"}`;
  card.appendChild(meta);

  // Price
  const price = document.createElement("div");
  price.className = "product-price";
  price.textContent = p.price != null ? `$${parseFloat(p.price).toFixed(2)}` : "N/A";
  card.appendChild(price);

  // Rating
  if (p.rating != null) {
    const ratingRow = document.createElement("div");
    ratingRow.className = "product-rating";
    const stars = document.createElement("span");
    stars.className = "stars";
    stars.textContent = buildStars(p.rating);
    ratingRow.appendChild(stars);
    ratingRow.appendChild(document.createTextNode(
      ` ${p.rating}/5  (${(p.reviews || 0).toLocaleString()} reviews)`
    ));
    card.appendChild(ratingRow);
  }

  // Features
  if (p.features && p.features.length > 0) {
    const featureRow = document.createElement("div");
    featureRow.className = "product-features";
    p.features.slice(0, 4).forEach(f => {
      const tag = document.createElement("span");
      tag.className = "feature-tag";
      tag.textContent = f;
      featureRow.appendChild(tag);
    });
    card.appendChild(featureRow);
  }

  // Description
  if (p.description) {
    const desc = document.createElement("div");
    desc.className = "product-desc";
    desc.textContent = truncate(p.description, 100);
    card.appendChild(desc);
  }

  return card;
}

/** Converts a 0–5 rating into ★★★★☆ stars. */
function buildStars(rating) {
  const full  = Math.round(parseFloat(rating));
  const empty = 5 - full;
  return "★".repeat(Math.max(0, full)) + "☆".repeat(Math.max(0, empty));
}

/** Returns the CSS class for a badge string. */
function getBadgeClass(badge) {
  if (badge.includes("Best"))    return "badge-best";
  if (badge.includes("Budget"))  return "badge-budget";
  if (badge.includes("Premium")) return "badge-premium";
  return "badge-best";
}

/** Truncates a string with ellipsis. */
function truncate(str, max) {
  return str && str.length > max ? str.slice(0, max).trimEnd() + "…" : str;
}

/* =============================================================
   INSIGHTS MODAL
   ============================================================= */

/** Opens the insights modal and loads data (once). */
async function openInsights() {
  insightsModal.hidden = false;
  if (insightsLoaded) return;

  insightsBody.innerHTML = '<div class="loading-spinner"></div>';

  try {
    const res  = await fetch("/api/insights");
    const data = await res.json();
    renderInsights(data);
    insightsLoaded = true;
  } catch (err) {
    insightsBody.innerHTML = '<p class="error-msg">⚠️ Failed to load insights.</p>';
    console.error("[ShopBot] Insights error:", err);
  }
}

/**
 * Renders the insights dashboard inside the modal.
 * @param {Object} data - Insights payload from /api/insights
 */
function renderInsights(data) {
  insightsBody.innerHTML = `
    <div class="insights-grid">
      <div class="stat-card">
        <div class="stat-value">${data.total_products}</div>
        <div class="stat-label">Total Products</div>
      </div>
      <div class="stat-card">
        <div class="stat-value">$${data.avg_price}</div>
        <div class="stat-label">Average Price</div>
      </div>
      <div class="stat-card">
        <div class="stat-value">${data.avg_rating} ★</div>
        <div class="stat-label">Average Rating</div>
      </div>
      <div class="stat-card">
        <div class="stat-value">${Object.keys(data.categories).length}</div>
        <div class="stat-label">Categories</div>
      </div>
    </div>

    <div style="margin-bottom:14px; font-size:13px; color:var(--text-muted)">
      🏆 Highest Rated: <strong>${data.highest_rated}</strong> &nbsp;·&nbsp;
      💰 Lowest Price: <strong>${data.lowest_price}</strong>
    </div>

    <div class="charts-grid">
      <div class="chart-card">
        <h4>Products by Category</h4>
        <canvas id="chart-category" height="220"></canvas>
      </div>
      <div class="chart-card">
        <h4>Price Distribution</h4>
        <canvas id="chart-price" height="220"></canvas>
      </div>
    </div>
  `;

  // Destroy old chart instances to prevent canvas reuse errors
  if (categoryChartInst) { categoryChartInst.destroy(); categoryChartInst = null; }
  if (priceChartInst)    { priceChartInst.destroy();    priceChartInst = null; }

  // Chart — Categories (doughnut)
  const catCtx = document.getElementById("chart-category").getContext("2d");
  categoryChartInst = new Chart(catCtx, {
    type: "doughnut",
    data: {
      labels: Object.keys(data.categories),
      datasets: [{
        data:  Object.values(data.categories),
        backgroundColor: [
          "#2563eb","#7c3aed","#16a34a","#d97706",
          "#dc2626","#0891b2","#be185d","#65a30d",
        ],
        borderWidth: 2,
        borderColor: "#fff",
      }],
    },
    options: {
      responsive: true,
      plugins: {
        legend: { position: "bottom", labels: { boxWidth: 12, font: { size: 11 } } },
      },
    },
  });

  // Chart — Price distribution (bar)
  const priceCtx = document.getElementById("chart-price").getContext("2d");
  priceChartInst = new Chart(priceCtx, {
    type: "bar",
    data: {
      labels: Object.keys(data.price_distribution),
      datasets: [{
        label: "# Products",
        data:  Object.values(data.price_distribution),
        backgroundColor: "#2563eb",
        borderRadius: 5,
      }],
    },
    options: {
      responsive: true,
      plugins: { legend: { display: false } },
      scales: {
        y: {
          beginAtZero: true,
          ticks: { stepSize: 1, font: { size: 11 } },
          grid: { color: "#f0f0f0" },
        },
        x: { ticks: { font: { size: 11 } }, grid: { display: false } },
      },
    },
  });
}

/* =============================================================
   PREFERENCES FORM
   ============================================================= */

/** Saves preferences via /api/preferences and shows confirmation. */
async function savePreferences(e) {
  e.preventDefault();
  const payload = {
    budget:   document.getElementById("pref-budget").value   || null,
    category: document.getElementById("pref-category").value || "",
    brand:    document.getElementById("pref-brand").value    || "",
    keywords: document.getElementById("pref-keywords").value || "",
  };

  try {
    const res = await fetch("/api/preferences", {
      method:  "POST",
      headers: { "Content-Type": "application/json" },
      body:    JSON.stringify(payload),
    });
    if (res.ok) {
      prefStatus.textContent = "✅ Preferences saved!";
      setTimeout(() => { prefStatus.textContent = ""; }, 2500);
    } else {
      prefStatus.textContent = "⚠️ Could not save preferences.";
      prefStatus.style.color = "var(--danger)";
    }
  } catch {
    prefStatus.textContent = "⚠️ Network error.";
    prefStatus.style.color = "var(--danger)";
  }
}

/* =============================================================
   QUICK SEARCH
   ============================================================= */

/**
 * Sends a predefined query directly from a chip button.
 * @param {string} query
 */
async function quickSearch(query) {
  if (isBotTyping) return;
  chatInput.value = query;
  await sendMessage();
}

/* =============================================================
   AUTO-RESIZE TEXTAREA
   ============================================================= */
function resizeTextarea() {
  chatInput.style.height = "auto";
  chatInput.style.height = Math.min(chatInput.scrollHeight, 120) + "px";
}

/* =============================================================
   EVENT LISTENERS
   ============================================================= */

// Send on Enter (but not Shift+Enter)
chatInput.addEventListener("keydown", e => {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    sendMessage();
  }
});

// Auto-resize
chatInput.addEventListener("input", resizeTextarea);

// Send button click
sendBtn.addEventListener("click", sendMessage);

// Quick-search chip buttons (sidebar)
document.querySelectorAll(".chip").forEach(btn => {
  btn.addEventListener("click", () => quickSearch(btn.dataset.query));
});

// Example chips (welcome screen)
document.querySelectorAll(".example-chip").forEach(chip => {
  chip.addEventListener("click", () => quickSearch(chip.dataset.query));
});

// Preferences form
prefForm.addEventListener("submit", savePreferences);

// Insights modal open / close
btnInsights.addEventListener("click", openInsights);

// ×  button: close the modal and stop the click reaching the overlay
closeInsights.addEventListener("click", e => {
  e.stopPropagation();
  insightsModal.hidden = true;
});

// Clicking the dark overlay backdrop (not the white modal box) also closes
insightsModal.addEventListener("click", e => {
  if (e.target === insightsModal) insightsModal.hidden = true;
});

// Prevent clicks inside the modal box from reaching the overlay listener
insightsModal.querySelector(".modal").addEventListener("click", e => {
  e.stopPropagation();
});

// Clear chat
btnClearChat.addEventListener("click", async () => {
  try {
    await fetch("/api/clear", { method: "POST" });
  } catch { /* ignore */ }
  messagesEl.innerHTML = "";
  productsSection.hidden = true;
  if (chatWelcome) chatWelcome.style.display = "flex";
});

// Hide products panel
btnCloseProducts.addEventListener("click", () => { productsSection.hidden = true; });

// Keyboard shortcut: Escape closes modal
document.addEventListener("keydown", e => {
  if (e.key === "Escape") insightsModal.hidden = true;
});
