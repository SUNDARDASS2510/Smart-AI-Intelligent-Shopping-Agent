"""
app.py — Flask application entry point for the Intelligent Shopping Agent.

Run with:
    python app.py

The app uses Flask sessions (server-side in-memory) to store chat history
and user preferences. No database is required.
"""

from flask import Flask
from config import SECRET_KEY, DEBUG, PORT
from routes import main_bp


def create_app() -> Flask:
    """
    Application factory: creates and configures the Flask app instance.
    Returns a fully wired Flask application.
    """
    app = Flask(__name__)

    # Secret key is required for session signing
    app.secret_key = SECRET_KEY

    # Session cookie settings (in-memory; no database)
    app.config["SESSION_TYPE"] = "filesystem"
    app.config["SESSION_COOKIE_HTTPONLY"] = True
    app.config["SESSION_COOKIE_SAMESITE"] = "Lax"

    # Register the main blueprint (all routes live in routes.py)
    app.register_blueprint(main_bp)

    return app


# ── Entry point ────────────────────────────────────────────────────
if __name__ == "__main__":
    app = create_app()
    print("=" * 60)
    print("  🛒  Intelligent Shopping Agent")
    print(f"  🌐  Running on  http://127.0.0.1:{PORT}")
    print("=" * 60)
    app.run(debug=DEBUG, port=PORT)
