"""
routes.py — All Flask route handlers for the Intelligent Shopping Agent.

Routes:
  GET  /                  → renders the main chat UI
  POST /api/chat          → sends a user message, returns AI response
  POST /api/search        → product text search
  POST /api/recommend     → preference-based recommendations
  POST /api/compare       → side-by-side product comparison
  GET  /api/products      → returns the full product catalog as JSON
  GET  /api/insights      → returns shopping insights / stats as JSON
  POST /api/preferences   → save user preferences to session
  POST /api/clear         → clear chat history from session
"""

from flask import (
    Blueprint,
    render_template,
    request,
    jsonify,
    session,
)
from config import SESSION_CHAT_HISTORY, SESSION_PREFERENCES, SESSION_CART
from services.watson_service import get_ai_response
from services.product_service import (
    search_products,
    get_all_products,
    get_product_insights,
)
from services.recommendation_service import (
    recommend_products,
    compare_products,
    get_buying_advice,
)
from utils.helpers import sanitize_input, format_chat_message

# All routes are grouped under this blueprint
main_bp = Blueprint("main", __name__)


# ── Page routes ─────────────────────────────────────────────────────

@main_bp.route("/")
def index():
    """Serve the main single-page chatbot UI."""
    # Initialise session structures on first visit
    if SESSION_CHAT_HISTORY not in session:
        session[SESSION_CHAT_HISTORY] = []
    if SESSION_PREFERENCES not in session:
        session[SESSION_PREFERENCES] = {}
    if SESSION_CART not in session:
        session[SESSION_CART] = []
    return render_template("index.html")


# ── API routes ───────────────────────────────────────────────────────

@main_bp.route("/api/chat", methods=["POST"])
def chat():
    """
    Main chat endpoint.
    Accepts: { "message": "..." }
    Returns: { "response": "...", "products": [...] }
    """
    data = request.get_json(silent=True) or {}
    user_message = sanitize_input(data.get("message", ""))

    if not user_message:
        return jsonify({"error": "Message cannot be empty."}), 400

    # Retrieve session state
    chat_history = session.get(SESSION_CHAT_HISTORY, [])
    preferences  = session.get(SESSION_PREFERENCES, {})

    # Detect intent keywords to enrich the prompt with product context
    intent_products = []
    lower_msg = user_message.lower()

    if any(kw in lower_msg for kw in ["search", "find", "show", "look", "want", "need", "buy"]):
        intent_products = search_products(user_message, limit=5)

    if any(kw in lower_msg for kw in ["recommend", "suggest", "best", "good", "top"]):
        intent_products = recommend_products(preferences, user_message, limit=5)

    if any(kw in lower_msg for kw in ["compare", "vs", "versus", "difference", "better"]):
        # extract product names by passing the full message to the compare engine
        intent_products = compare_products(user_message)

    # Build a rich AI response using the product context
    ai_response = get_ai_response(
        user_message=user_message,
        chat_history=chat_history,
        product_context=intent_products,
        preferences=preferences,
    )

    # Persist conversation turn to session
    chat_history.append(format_chat_message("user", user_message))
    chat_history.append(format_chat_message("assistant", ai_response))
    # Keep only the last 20 messages to avoid session bloat
    session[SESSION_CHAT_HISTORY] = chat_history[-20:]
    session.modified = True

    return jsonify({
        "response": ai_response,
        "products": intent_products[:6],   # send at most 6 product cards
    })


@main_bp.route("/api/search", methods=["POST"])
def product_search():
    """
    Product search endpoint.
    Accepts: { "query": "laptop under 1000", "limit": 10 }
    Returns: { "products": [...] }
    """
    data  = request.get_json(silent=True) or {}
    query = sanitize_input(data.get("query", ""))
    limit = min(int(data.get("limit", 8)), 20)

    if not query:
        return jsonify({"error": "Search query cannot be empty."}), 400

    products = search_products(query, limit=limit)
    return jsonify({"products": products, "count": len(products)})


@main_bp.route("/api/recommend", methods=["POST"])
def get_recommendations():
    """
    Preference-based recommendation endpoint.
    Accepts: { "budget": 500, "category": "Electronics", "brand": "Sony" }
    Returns: { "products": [...], "advice": "..." }
    """
    data        = request.get_json(silent=True) or {}
    preferences = {
        "budget":   data.get("budget"),
        "category": sanitize_input(data.get("category", "")),
        "brand":    sanitize_input(data.get("brand", "")),
        "keywords": sanitize_input(data.get("keywords", "")),
    }

    # Persist preferences in session for subsequent chat turns
    session[SESSION_PREFERENCES] = preferences
    session.modified = True

    products = recommend_products(preferences, limit=8)
    advice   = get_buying_advice(products)

    return jsonify({"products": products, "advice": advice})


@main_bp.route("/api/compare", methods=["POST"])
def product_compare():
    """
    Product comparison endpoint.
    Accepts: { "query": "compare iPhone vs Samsung" }
      OR     { "product_ids": [1, 2] }
    Returns: { "products": [...], "comparison": {...} }
    """
    data  = request.get_json(silent=True) or {}
    query = sanitize_input(data.get("query", ""))
    ids   = data.get("product_ids", [])

    if not query and not ids:
        return jsonify({"error": "Provide a comparison query or product IDs."}), 400

    if ids:
        from services.product_service import get_products_by_ids
        products = get_products_by_ids(ids)
    else:
        products = compare_products(query)

    if len(products) < 2:
        return jsonify({"error": "Need at least 2 products to compare."}), 404

    advice = get_buying_advice(products)
    return jsonify({"products": products, "advice": advice})


@main_bp.route("/api/products", methods=["GET"])
def all_products():
    """Returns the full product catalog."""
    category = request.args.get("category", "")
    products = get_all_products(category_filter=category)
    return jsonify({"products": products})


@main_bp.route("/api/insights", methods=["GET"])
def insights():
    """Returns shopping insights and stats for dashboard charts."""
    return jsonify(get_product_insights())


@main_bp.route("/api/preferences", methods=["POST"])
def save_preferences():
    """Save user shopping preferences to the session."""
    data = request.get_json(silent=True) or {}
    session[SESSION_PREFERENCES] = {
        "budget":   data.get("budget"),
        "category": sanitize_input(data.get("category", "")),
        "brand":    sanitize_input(data.get("brand", "")),
        "keywords": sanitize_input(data.get("keywords", "")),
    }
    session.modified = True
    return jsonify({"status": "ok", "preferences": session[SESSION_PREFERENCES]})


@main_bp.route("/api/clear", methods=["POST"])
def clear_chat():
    """Clear the chat history from the session."""
    session[SESSION_CHAT_HISTORY] = []
    session.modified = True
    return jsonify({"status": "ok"})
